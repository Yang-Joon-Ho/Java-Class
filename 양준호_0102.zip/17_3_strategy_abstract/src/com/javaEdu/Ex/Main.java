package com.javaEdu.Ex;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Low low = new Low();
		low.print();
		
		Standard standard = new Standard();
		standard.print();
		
		Super superRobot = new Super();
		superRobot.print();
		
	}
}
