package com.javaEdu.Ex;

public interface Light {

	public void launchLight();
	
}
