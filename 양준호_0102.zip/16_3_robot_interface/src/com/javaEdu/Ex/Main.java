package com.javaEdu.Ex;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Bear bear = new Bear();
		bear.print();
		
		Plane plane = new Plane();
		plane.print();
		
		Majing majing = new Majing();
		majing.print();
		
	}
}
