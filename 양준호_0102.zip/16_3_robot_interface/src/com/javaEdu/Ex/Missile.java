package com.javaEdu.Ex;

public interface Missile {

	public void launchMissile();
	
}
