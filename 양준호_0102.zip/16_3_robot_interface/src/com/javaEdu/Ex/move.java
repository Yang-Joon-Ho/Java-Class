package com.javaEdu.Ex;

public interface move {
	
	public void move();
	
}
