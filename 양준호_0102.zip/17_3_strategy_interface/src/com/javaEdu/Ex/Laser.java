package com.javaEdu.Ex;

public interface Laser {
	
	public void laser();
}
