package com.javaEdu.Ex;

public interface Fly {

	public void fly();
	
}
