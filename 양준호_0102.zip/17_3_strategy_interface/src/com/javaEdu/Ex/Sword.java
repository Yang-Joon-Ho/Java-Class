package com.javaEdu.Ex;

public interface Sword {

	public void sword();
}
