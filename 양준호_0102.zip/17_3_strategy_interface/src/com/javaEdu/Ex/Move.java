package com.javaEdu.Ex;

public interface Move {
	
	public void move();

}
