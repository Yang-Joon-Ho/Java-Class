package com.javaEdu.Ex;

public class C_model implements Samsung{

	public C_model() {
		System.out.println("-------------C ��------------");
	}
	
	public void networkSpeed() {
		// TODO Auto-generated method stub
		System.out.println("���� �ӵ� : " + "4G");
	}

	public void TV() {
		// TODO Auto-generated method stub
		System.out.println("������ ��� ž��");
	}

}
