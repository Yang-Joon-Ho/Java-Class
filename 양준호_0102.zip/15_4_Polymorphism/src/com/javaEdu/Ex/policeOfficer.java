package com.javaEdu.Ex;

public interface policeOfficer{

	//���� 1
	public void find();

	//���� 2
	public void stuff();
	
	public void policePrint();
}
