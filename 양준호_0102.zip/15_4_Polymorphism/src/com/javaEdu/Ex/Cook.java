package com.javaEdu.Ex;

public interface Cook{
										
	//���� 1
	public void pizza();

	//���� 2
	public void pasta();
	
	public void cookPrint();
}
