package com.javaEdu.Ex;

public interface fireFighter{
	
	//���� 1
	public void fire();

	//���� 2
	public void people();
	
	public void firePrint();
}
