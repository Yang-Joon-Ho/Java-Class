package com.javaEdu.Ex;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FirstClass first = new FirstClass();
		SecondClass second = new SecondClass();
		
	}
}
