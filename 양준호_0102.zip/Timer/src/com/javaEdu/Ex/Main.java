package com.javaEdu.Ex;

public class Main {

}
