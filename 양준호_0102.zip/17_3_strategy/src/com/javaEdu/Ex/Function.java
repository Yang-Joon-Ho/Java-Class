package com.javaEdu.Ex;

public interface Function {
	
	public abstract void fly();
	public abstract void laserSword();
	public abstract void missile();
	public abstract void move();
	public abstract void sword();
}
